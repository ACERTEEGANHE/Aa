# Acerte & Ganhe — projeto Android em tela cheia

Este projeto transforma https://acerteeganhe.netlify.app/ em um aplicativo Android usando WebView.

## O que já está configurado
- Nome do aplicativo: Acerte & Ganhe
- Abre diretamente o site publicado no Netlify
- Sem barra de endereço/pesquisa nem barra de ferramentas do navegador
- Modo imersivo: oculta a barra de status e a navegação do Android durante o uso
- JavaScript e armazenamento local habilitados para o jogo
- Ícone baseado na logo enviada
- Botão Voltar navega para a página anterior quando possível

## Gerar o APK
1. Abra o projeto `AndroidAcerteGanhe` no Android Studio.
2. Aguarde a sincronização do Gradle e instale o Android SDK 35 se for solicitado.
3. No menu, escolha **Build > Build APK(s)**.
4. O APK de teste normalmente fica em `app/build/outputs/apk/debug/app-debug.apk`.

Este pacote é o projeto-fonte pronto para compilação; o ambiente em que ele foi preparado não possui Android SDK/Gradle nem acesso à rede para baixar as ferramentas, portanto não foi possível compilar um APK binário aqui.
